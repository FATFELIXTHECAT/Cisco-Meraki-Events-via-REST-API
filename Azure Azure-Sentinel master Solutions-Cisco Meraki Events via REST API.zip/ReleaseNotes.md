| **Version** | **Date Modified (DD-MM-YYYY)** | **Change History**                                                 |
|-------------|--------------------------------|--------------------------------------------------------------------|
| 3.0.2       | 10-01-2025                     | Transitioned the **CCP Connector** to General Availability (GA).    |
| 3.0.1       | 30-09-2024                     | Cisco Meraki via REST API configuration Changes pagination fix     |
| 3.0.0       | 27-12-2023                     | Initial Solution Release with new addition of **CCP Connector**                                  |
